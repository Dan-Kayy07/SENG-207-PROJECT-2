import PySimpleGui as sg
import pyttsx3

tts_engine = pyttsx3.init()
voice_types = tts_engine.getProperty('voices')



layout = [    [sg.Text('Select the type of voice:',text_color='black',background_color='yellow'),sg.Radio('Kofi', 'RADIO1', default=True, key='Kofi',background_color='green'),sg.Radio('Ama', 'RADIO1', key='Ama',background_color='green')],
     [sg.Text('Enter text to speak:',text_color='white',background_color='red',)],
          
    [sg.InputText(key='user_input'),sg.Button('Speak',button_color='red')],
   
    
]

window = sg.Window('JARVIS', layout,background_color='black')

while True:
    event, values = window.read()
    if event == sg.WINDOW_CLOSED:
        break
    elif event == 'Speak':
        text = values['user_input']
        if values['Kofi']:
            tts_engine.setProperty('voice', voice_types[0].id)
        elif values['Ama']:
           tts_engine.setProperty('voice', voice_types[1].id) 
    
        tts_engine.say(text)
        tts_engine.runAndWait()

window.close()